#!/bin/bash
set -e

ZIP_FILE="2o3aGkTJJHCsocUgngKK8A (1).zip"
PROJECT_DIR="CelconexProject"
OUTPUT_DIR="output_aab"

echo "📦 Descomprimiendo proyecto..."
rm -rf "$PROJECT_DIR" "$OUTPUT_DIR"
mkdir -p "$PROJECT_DIR"
unzip -q "$ZIP_FILE" -d "$PROJECT_DIR"

echo "⚙️ Entrando al proyecto..."
cd "$PROJECT_DIR"/*

echo "🔧 Dando permisos a gradlew..."
chmod +x gradlew

echo "🏗️ Construyendo App Bundle..."
./gradlew clean bundleRelease

echo "📂 Copiando resultado..."
cd ..
mkdir -p "../$OUTPUT_DIR"
find . -name "*.aab" -exec cp {} "../$OUTPUT_DIR/" \;

cd ..
echo "✅ App Bundle generado en: $OUTPUT_DIR/"
ls -lh "$OUTPUT_DIR"
