import React, { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
  interpolate,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors } from '@/constants/Colors';

interface WifiWavesProps {
  size?: number;
  active?: boolean;
}

export default function WifiWaves({ size = 120, active = true }: WifiWavesProps) {
  const wave1 = useSharedValue(0);
  const wave2 = useSharedValue(0);
  const wave3 = useSharedValue(0);

  useEffect(() => {
    if (active) {
      wave1.value = withRepeat(withTiming(1, { duration: 2000 }), -1);
      wave2.value = withRepeat(withTiming(1, { duration: 2500 }), -1);
      wave3.value = withRepeat(withTiming(1, { duration: 3000 }), -1);
    }
  }, [active]);

  const wave1Style = useAnimatedStyle(() => ({
    transform: [{ scale: interpolate(wave1.value, [0, 1], [0.8, 1.2]) }],
    opacity: interpolate(wave1.value, [0, 0.5, 1], [0.3, 0.8, 0.3]),
  }));

  const wave2Style = useAnimatedStyle(() => ({
    transform: [{ scale: interpolate(wave2.value, [0, 1], [0.6, 1.4]) }],
    opacity: interpolate(wave2.value, [0, 0.5, 1], [0.2, 0.6, 0.2]),
  }));

  const wave3Style = useAnimatedStyle(() => ({
    transform: [{ scale: interpolate(wave3.value, [0, 1], [0.4, 1.6]) }],
    opacity: interpolate(wave3.value, [0, 0.5, 1], [0.1, 0.4, 0.1]),
  }));

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <Animated.View style={[styles.wave, wave3Style, { width: size, height: size }]}>
        <LinearGradient
          colors={Colors.gradient.wifi}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      </Animated.View>
      
      <Animated.View style={[styles.wave, wave2Style, { width: size * 0.8, height: size * 0.8 }]}>
        <LinearGradient
          colors={Colors.gradient.wifi}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      </Animated.View>
      
      <Animated.View style={[styles.wave, wave1Style, { width: size * 0.6, height: size * 0.6 }]}>
        <LinearGradient
          colors={Colors.gradient.wifi}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      </Animated.View>
      
      <View style={[styles.center, { width: size * 0.3, height: size * 0.3 }]}>
        <LinearGradient
          colors={[Colors.primary, Colors.accent]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  wave: {
    position: 'absolute',
    borderRadius: 1000,
    borderWidth: 3,
    borderColor: 'transparent',
  },
  center: {
    borderRadius: 1000,
    elevation: 8,
    shadowColor: Colors.accent,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
});