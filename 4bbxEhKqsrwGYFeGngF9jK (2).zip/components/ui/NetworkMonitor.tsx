
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors } from '@/constants/Colors';

interface NetworkMonitorProps {
  isActive?: boolean;
  onStatusChange?: (status: 'excellent' | 'good' | 'poor' | 'offline') => void;
}

export default function NetworkMonitor({ isActive = false, onStatusChange }: NetworkMonitorProps) {
  const [signalStrength, setSignalStrength] = useState(4);
  const [networkType, setNetworkType] = useState('5G');
  const [dataSpeed, setDataSpeed] = useState('0.0');
  const [status, setStatus] = useState<'excellent' | 'good' | 'poor' | 'offline'>('good');

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      // Simulate network monitoring
      const newSignal = Math.floor(Math.random() * 5) + 1;
      const newSpeed = (Math.random() * 100 + 10).toFixed(1);
      
      setSignalStrength(newSignal);
      setDataSpeed(newSpeed);

      // Determine status based on signal and speed
      let newStatus: typeof status = 'offline';
      if (newSignal >= 4 && parseFloat(newSpeed) > 50) {
        newStatus = 'excellent';
      } else if (newSignal >= 3 && parseFloat(newSpeed) > 25) {
        newStatus = 'good';
      } else if (newSignal >= 2) {
        newStatus = 'poor';
      }
      
      setStatus(newStatus);
      onStatusChange?.(newStatus);
    }, 2000);

    return () => clearInterval(interval);
  }, [isActive, onStatusChange]);

  const getStatusColor = () => {
    switch (status) {
      case 'excellent': return Colors.success;
      case 'good': return Colors.accent;
      case 'poor': return Colors.warning;
      case 'offline': return Colors.error;
      default: return Colors.text; // Add a default return for exhaustive checking
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'excellent': return 'Excelente';
      case 'good': return 'Buena';
      case 'poor': return 'Regular';
      case 'offline': return 'Sin conexión';
      default: return 'Desconocido'; // Add a default return
    }
  };

  const getSignalIcon = () => {
    if (signalStrength <= 1) return 'signal-cellular-1-bar';
    if (signalStrength <= 2) return 'signal-cellular-2-bar';
    if (signalStrength <= 3) return 'signal-cellular-3-bar';
    return 'signal-cellular-4-bar';
  };

  return (
    <LinearGradient
      colors={[Colors.surface, Colors.surfaceLight]}
      style={styles.container}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
    >
      <View style={styles.header}>
        <MaterialIcons name="network-check" size={20} color={Colors.accent} />
        <Text style={styles.title}>Monitor de Red</Text>
        {isActive && (
          <View style={[styles.activeIndicator, { backgroundColor: getStatusColor() }]} />
        )}
      </View>

      <View style={styles.metrics}>
        <View style={styles.metricItem}>
          <MaterialIcons name={getSignalIcon() as any} size={24} color={getStatusColor()} />
          <Text style={styles.metricValue}>{networkType}</Text>
          <Text style={styles.metricLabel}>Red</Text>
        </View>

        <View style={styles.divider} />

        <View style={styles.metricItem}>
          <MaterialIcons name="speed" size={24} color={getStatusColor()} />
          <Text style={styles.metricValue}>{dataSpeed} Mbps</Text>
          <Text style={styles.metricLabel}>Velocidad</Text>
        </View>

        <View style={styles.divider} />

        <View style={styles.metricItem}>
          <MaterialIcons name="cell-tower" size={24} color={getStatusColor()} />
          <Text style={styles.metricValue}>{signalStrength}/5</Text>
          <Text style={styles.metricLabel}>Señal</Text>
        </View>
      </View>

      <View style={styles.footer}>
        <View style={[styles.statusIndicator, { backgroundColor: getStatusColor() }]} />
        <Text style={[styles.statusText, { color: getStatusColor() }]}>
          {getStatusText()}
        </Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    padding: 16,
    marginVertical: 8,
    elevation: 3,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 1.5 },
    shadowOpacity: 0.15,
    shadowRadius: 3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    marginLeft: 8,
    flex: 1,
  },
  activeIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  metrics: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  metricItem: {
    alignItems: 'center',
    flex: 1,
  },
  metricValue: {
    fontSize: 12,
    fontWeight: 'bold',
    color: Colors.text,
    marginTop: 4,
  },
  metricLabel: {
    fontSize: 10,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  divider: {
    width: 1,
    height: 40,
    backgroundColor: Colors.surfaceLight,
    marginHorizontal: 8,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusIndicator: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 6,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
});
