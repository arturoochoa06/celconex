import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, TextInput, Alert, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors } from '@/constants/Colors';
import GradientButton from '@/components/ui/GradientButton';
import DataCard from '@/components/ui/DataCard';

export default function SettingsScreen() {
  // Data Limits
  const [dailyDataLimit, setDailyDataLimit] = useState('500');
  const [monthlyDataLimit, setMonthlyDataLimit] = useState('10000');
  const [sessionTimeLimit, setSessionTimeLimit] = useState('120'); // minutes
  const [maxDevices, setMaxDevices] = useState('3');
  
  // Security Settings
  const [requireApproval, setRequireApproval] = useState(true);
  const [allowUnknownDevices, setAllowUnknownDevices] = useState(false);
  const [encryptionEnabled, setEncryptionEnabled] = useState(true);
  const [autoDisconnect, setAutoDisconnect] = useState(true);
  
  // Notification Settings
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [dataLimitAlerts, setDataLimitAlerts] = useState(true);
  const [connectionAlerts, setConnectionAlerts] = useState(true);
  const [securityAlerts, setSecurityAlerts] = useState(true);
  
  // Advanced Settings
  const [powerSaving, setPowerSaving] = useState(true);
  const [backgroundSharing, setBackgroundSharing] = useState(false);
  const [highQualityMode, setHighQualityMode] = useState(false);
  const [dataCompression, setDataCompression] = useState(true);

  // Scheduled Sharing
  const [scheduledSharing, setScheduledSharing] = useState(false);
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('21:00');

  const showAlert = (title: string, message: string) => {
    if (Platform.OS === 'web') {
      console.log(`${title}: ${message}`);
    } else {
      Alert.alert(title, message);
    }
  };

  const handleSaveSettings = () => {
    showAlert('Configuración Guardada', 'Tus preferencias han sido actualizadas correctamente');
  };

  const handleResetSettings = () => {
    // Reset to defaults
    setDailyDataLimit('500');
    setMonthlyDataLimit('10000');
    setSessionTimeLimit('120');
    setMaxDevices('3');
    setRequireApproval(true);
    setAllowUnknownDevices(false);
    setEncryptionEnabled(true);
    setAutoDisconnect(true);
    setNotificationsEnabled(true);
    setDataLimitAlerts(true);
    setConnectionAlerts(true);
    setSecurityAlerts(true);
    setPowerSaving(true);
    setBackgroundSharing(false);
    setHighQualityMode(false);
    setDataCompression(true);
    setScheduledSharing(false);
    
    showAlert('Configuración Restablecida', 'Se han restaurado los valores predeterminados');
  };

  const handleExportSettings = () => {
    showAlert('Configuración Exportada', 'Tu configuración se ha exportado como respaldo');
  };

  return (
    <SafeAreaView edges={['top', 'bottom']} style={styles.container}>
      <LinearGradient
        colors={[Colors.background, Colors.surface]}
        style={StyleSheet.absoluteFill}
      />

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <GradientButton
            title="← Volver"
            onPress={() => router.back()}
            variant="secondary"
            style={styles.backButton}
          />
          <Text style={styles.title}>Configuración Avanzada</Text>
        </View>

        {/* Data Limits Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Límites de Datos</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Límite Diario (MB)</Text>
            <View style={styles.inputContainer}>
              <MaterialIcons name="data-usage" size={20} color={Colors.textSecondary} />
              <TextInput
                style={styles.input}
                value={dailyDataLimit}
                onChangeText={setDailyDataLimit}
                placeholder="500"
                keyboardType="decimal-pad"
                placeholderTextColor={Colors.textSecondary}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Límite Mensual (MB)</Text>
            <View style={styles.inputContainer}>
              <MaterialIcons name="calendar-today" size={20} color={Colors.textSecondary} />
              <TextInput
                style={styles.input}
                value={monthlyDataLimit}
                onChangeText={setMonthlyDataLimit}
                placeholder="10000"
                keyboardType="decimal-pad"
                placeholderTextColor={Colors.textSecondary}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Tiempo Máximo por Sesión (minutos)</Text>
            <View style={styles.inputContainer}>
              <MaterialIcons name="timer" size={20} color={Colors.textSecondary} />
              <TextInput
                style={styles.input}
                value={sessionTimeLimit}
                onChangeText={setSessionTimeLimit}
                placeholder="120"
                keyboardType="number-pad"
                placeholderTextColor={Colors.textSecondary}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Máximo de Dispositivos Simultáneos</Text>
            <View style={styles.inputContainer}>
              <MaterialIcons name="devices" size={20} color={Colors.textSecondary} />
              <TextInput
                style={styles.input}
                value={maxDevices}
                onChangeText={setMaxDevices}
                placeholder="3"
                keyboardType="number-pad"
                placeholderTextColor={Colors.textSecondary}
              />
            </View>
          </View>
        </View>

        {/* Security & Privacy Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Seguridad y Privacidad</Text>
          
          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="security" size={24} color={Colors.success} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Requerir Aprobación Manual</Text>
                <Text style={styles.settingSubtitle}>Aprobar cada solicitud de conexión manualmente</Text>
              </View>
            </View>
            <Switch
              value={requireApproval}
              onValueChange={setRequireApproval}
              trackColor={{ false: Colors.surfaceLight, true: Colors.success }}
              thumbColor={requireApproval ? Colors.text : Colors.textSecondary}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="block" size={24} color={Colors.warning} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Permitir Dispositivos Desconocidos</Text>
                <Text style={styles.settingSubtitle}>Permitir conexiones de dispositivos nuevos</Text>
              </View>
            </View>
            <Switch
              value={allowUnknownDevices}
              onValueChange={setAllowUnknownDevices}
              trackColor={{ false: Colors.surfaceLight, true: Colors.warning }}
              thumbColor={allowUnknownDevices ? Colors.text : Colors.textSecondary}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="lock" size={24} color={Colors.accent} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Cifrado de Extremo a Extremo</Text>
                <Text style={styles.settingSubtitle}>Todo el tráfico estará cifrado y seguro</Text>
              </View>
            </View>
            <Switch
              value={encryptionEnabled}
              onValueChange={setEncryptionEnabled}
              trackColor={{ false: Colors.surfaceLight, true: Colors.accent }}
              thumbColor={encryptionEnabled ? Colors.text : Colors.textSecondary}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="logout" size={24} color={Colors.error} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Desconexión Automática</Text>
                <Text style={styles.settingSubtitle}>Desconectar automáticamente al alcanzar límites</Text>
              </View>
            </View>
            <Switch
              value={autoDisconnect}
              onValueChange={setAutoDisconnect}
              trackColor={{ false: Colors.surfaceLight, true: Colors.error }}
              thumbColor={autoDisconnect ? Colors.text : Colors.textSecondary}
            />
          </View>
        </View>

        {/* Scheduled Sharing Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Compartir Programado</Text>
          
          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="schedule" size={24} color={Colors.primary} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Activar Horario Programado</Text>
                <Text style={styles.settingSubtitle}>Solo permitir compartir en horarios específicos</Text>
              </View>
            </View>
            <Switch
              value={scheduledSharing}
              onValueChange={setScheduledSharing}
              trackColor={{ false: Colors.surfaceLight, true: Colors.primary }}
              thumbColor={scheduledSharing ? Colors.text : Colors.textSecondary}
            />
          </View>

          {scheduledSharing && (
            <>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Hora de Inicio</Text>
                <View style={styles.inputContainer}>
                  <MaterialIcons name="access-time" size={20} color={Colors.textSecondary} />
                  <TextInput
                    style={styles.input}
                    value={startTime}
                    onChangeText={setStartTime}
                    placeholder="09:00"
                    placeholderTextColor={Colors.textSecondary}
                  />
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Hora de Fin</Text>
                <View style={styles.inputContainer}>
                  <MaterialIcons name="access-time" size={20} color={Colors.textSecondary} />
                  <TextInput
                    style={styles.input}
                    value={endTime}
                    onChangeText={setEndTime}
                    placeholder="21:00"
                    placeholderTextColor={Colors.textSecondary}
                  />
                </View>
              </View>
            </>
          )}
        </View>

        {/* Notifications Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Notificaciones</Text>
          
          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="notifications" size={24} color={Colors.accent} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Notificaciones Generales</Text>
                <Text style={styles.settingSubtitle}>Recibir todas las notificaciones de la app</Text>
              </View>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              trackColor={{ false: Colors.surfaceLight, true: Colors.accent }}
              thumbColor={notificationsEnabled ? Colors.text : Colors.textSecondary}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="data-usage" size={24} color={Colors.warning} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Alertas de Límite de Datos</Text>
                <Text style={styles.settingSubtitle}>Notificar al acercarse a los límites establecidos</Text>
              </View>
            </View>
            <Switch
              value={dataLimitAlerts}
              onValueChange={setDataLimitAlerts}
              trackColor={{ false: Colors.surfaceLight, true: Colors.warning }}
              thumbColor={dataLimitAlerts ? Colors.text : Colors.textSecondary}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="wifi" size={24} color={Colors.success} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Alertas de Conexión</Text>
                <Text style={styles.settingSubtitle}>Notificar sobre nuevas conexiones y desconexiones</Text>
              </View>
            </View>
            <Switch
              value={connectionAlerts}
              onValueChange={setConnectionAlerts}
              trackColor={{ false: Colors.surfaceLight, true: Colors.success }}
              thumbColor={connectionAlerts ? Colors.text : Colors.textSecondary}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="warning" size={24} color={Colors.error} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Alertas de Seguridad</Text>
                <Text style={styles.settingSubtitle}>Notificar sobre intentos de acceso no autorizados</Text>
              </View>
            </View>
            <Switch
              value={securityAlerts}
              onValueChange={setSecurityAlerts}
              trackColor={{ false: Colors.surfaceLight, true: Colors.error }}
              thumbColor={securityAlerts ? Colors.text : Colors.textSecondary}
            />
          </View>
        </View>

        {/* Advanced Performance Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Rendimiento Avanzado</Text>
          
          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="battery-saver" size={24} color={Colors.success} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Modo Ahorro de Energía</Text>
                <Text style={styles.settingSubtitle}>Reduce consumo cuando la batería es baja</Text>
              </View>
            </View>
            <Switch
              value={powerSaving}
              onValueChange={setPowerSaving}
              trackColor={{ false: Colors.surfaceLight, true: Colors.success }}
              thumbColor={powerSaving ? Colors.text : Colors.textSecondary}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="cloud-queue" size={24} color={Colors.primary} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Compartir en Segundo Plano</Text>
                <Text style={styles.settingSubtitle}>Permitir compartir datos cuando la app esté minimizada</Text>
              </View>
            </View>
            <Switch
              value={backgroundSharing}
              onValueChange={setBackgroundSharing}
              trackColor={{ false: Colors.surfaceLight, true: Colors.primary }}
              thumbColor={backgroundSharing ? Colors.text : Colors.textSecondary}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="high-quality" size={24} color={Colors.accent} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Modo Alta Calidad</Text>
                <Text style={styles.settingSubtitle}>Prioriza velocidad sobre consumo de batería</Text>
              </View>
            </View>
            <Switch
              value={highQualityMode}
              onValueChange={setHighQualityMode}
              trackColor={{ false: Colors.surfaceLight, true: Colors.accent }}
              thumbColor={highQualityMode ? Colors.text : Colors.textSecondary}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <MaterialIcons name="compress" size={24} color={Colors.warning} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Compresión de Datos</Text>
                <Text style={styles.settingSubtitle}>Comprime datos para reducir el uso de ancho de banda</Text>
              </View>
            </View>
            <Switch
              value={dataCompression}
              onValueChange={setDataCompression}
              trackColor={{ false: Colors.surfaceLight, true: Colors.warning }}
              thumbColor={dataCompression ? Colors.text : Colors.textSecondary}
            />
          </View>
        </View>

        {/* System Status */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Estado del Sistema</Text>
          <DataCard
            title="Temperatura del Procesador"
            value="38°C"
            subtitle="Óptima - Sistema funcionando correctamente"
            icon="thermostat"
            trend="neutral"
          />
          
          <DataCard
            title="Uso de Memoria"
            value="54%"
            subtitle="1.6 GB de 3.0 GB utilizados"
            icon="memory"
            trend="neutral"
          />

          <DataCard
            title="Conexiones Activas"
            value="2"
            subtitle="2 dispositivos conectados actualmente"
            icon="devices"
            trend="up"
          />
        </View>

        {/* Action Buttons */}
        <View style={styles.actions}>
          <GradientButton
            title="Guardar Configuración"
            onPress={handleSaveSettings}
            style={styles.actionButton}
          />
          
          <GradientButton
            title="Exportar Configuración"
            onPress={handleExportSettings}
            variant="secondary"
            style={styles.actionButton}
          />
          
          <GradientButton
            title="Restablecer a Valores Predeterminados"
            onPress={handleResetSettings}
            variant="secondary"
            style={styles.actionButton}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 30,
  },
  backButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
    flex: 1,
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingText: {
    marginLeft: 12,
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
  },
  settingSubtitle: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: Colors.surfaceLight,
  },
  input: {
    flex: 1,
    color: Colors.text,
    fontSize: 16,
    paddingVertical: 12,
    marginLeft: 12,
  },
  actions: {
    marginTop: 20,
    gap: 12,
  },
  actionButton: {
    marginBottom: 8,
  },
});