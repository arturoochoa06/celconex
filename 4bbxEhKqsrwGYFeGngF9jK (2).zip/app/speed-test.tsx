
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Platform, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors } from '@/constants/Colors';
import GradientButton from '@/components/ui/GradientButton';
import DataCard from '@/components/ui/DataCard';

export default function SpeedTestScreen() {
  const [isRunning, setIsRunning] = useState(false);
  const [testProgress, setTestProgress] = useState(0);
  const [downloadSpeed, setDownloadSpeed] = useState('0');
  const [uploadSpeed, setUploadSpeed] = useState('0');
  const [ping, setPing] = useState('0');
  const [testPhase, setTestPhase] = useState('idle');

  const showAlert = (title: string, message: string) => {
    if (Platform.OS === 'web') {
      console.log(`${title}: ${message}`);
    } else {
      Alert.alert(title, message);
    }
  };

  const runSpeedTest = async () => {
    setIsRunning(true);
    setTestProgress(0);
    setDownloadSpeed('0');
    setUploadSpeed('0');
    setPing('0');

    // Simulated speed test sequence
    const phases = [
      { name: 'ping', duration: 1000, label: 'Midiendo latencia...' },
      { name: 'download', duration: 3000, label: 'Probando descarga...' },
      { name: 'upload', duration: 2000, label: 'Probando subida...' },
      { name: 'complete', duration: 500, label: 'Completando test...' }
    ];

    for (let i = 0; i < phases.length; i++) {
      const phase = phases[i];
      setTestPhase(phase.label);
      
      const startTime = Date.now();
      while (Date.now() - startTime < phase.duration) {
        const progress = ((Date.now() - startTime) / phase.duration) * 100;
        setTestProgress((i * 25) + (progress / 4));
        
        // Simulate progressive measurements
        if (phase.name === 'ping') {
          setPing(Math.floor(Math.random() * 20 + 10).toString());
        } else if (phase.name === 'download') {
          setDownloadSpeed((Math.random() * 100 + 20).toFixed(1));
        } else if (phase.name === 'upload') {
          setUploadSpeed((Math.random() * 50 + 10).toFixed(1));
        }
        
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    }

    setIsRunning(false);
    setTestProgress(100);
    setTestPhase('Test completado');
    showAlert('Test Completado', 'Prueba de velocidad finalizada correctamente');
  };

  const networkDiagnostics = [
    { label: 'Servidor', value: 'Miami, FL', icon: 'location-on', status: 'good' },
    { label: 'ISP', value: 'Telcel México', icon: 'business', status: 'good' },
    { label: 'Tipo de Red', value: '5G NSA', icon: 'network-cell', status: 'excellent' },
    { label: 'IPv4', value: '192.168.1.105', icon: 'computer', status: 'good' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return Colors.success;
      case 'good': return Colors.accent;
      case 'warning': return Colors.warning;
      default: return Colors.textSecondary;
    }
  };

  const getSpeedQuality = (speed: number) => {
    if (speed > 50) return { label: 'Excelente', color: Colors.success };
    if (speed > 25) return { label: 'Buena', color: Colors.accent };
    if (speed > 10) return { label: 'Regular', color: Colors.warning };
    return { label: 'Lenta', color: Colors.error };
  };

  const downloadQuality = getSpeedQuality(parseFloat(downloadSpeed));
  const uploadQuality = getSpeedQuality(parseFloat(uploadSpeed));

  return (
    <SafeAreaView edges={['top', 'bottom']} style={styles.container}>
      <LinearGradient
        colors={[Colors.background, Colors.surface]}
        style={StyleSheet.absoluteFill}
      />

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <GradientButton
            title="← Volver"
            onPress={() => router.back()}
            variant="secondary"
            style={styles.backButton}
          />
          <Text style={styles.title}>Test de Velocidad</Text>
        </View>

        {/* Speed Test Widget */}
        <LinearGradient
          colors={[Colors.surface, Colors.surfaceLight]}
          style={styles.speedTestContainer}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <Text style={styles.speedTestTitle}>Prueba de Velocidad de Red</Text>
          
          {/* Progress Circle */}
          <View style={styles.progressContainer}>
            <LinearGradient
              colors={Colors.gradient.wifi}
              style={styles.progressCircle}
            >
              <Text style={styles.progressText}>
                {isRunning ? `${Math.round(testProgress)}%` : 'Iniciar'}
              </Text>
            </LinearGradient>
          </View>

          <Text style={styles.testPhase}>{testPhase}</Text>

          {/* Speed Results */}
          <View style={styles.speedResults}>
            <View style={styles.speedItem}>
              <MaterialIcons name="file-download" size={24} color={downloadQuality.color} />
              <Text style={styles.speedValue}>{downloadSpeed}</Text>
              <Text style={styles.speedUnit}>Mbps</Text>
              <Text style={styles.speedLabel}>Descarga</Text>
              <Text style={[styles.speedQuality, { color: downloadQuality.color }]}>
                {downloadQuality.label}
              </Text>
            </View>

            <View style={styles.speedDivider} />

            <View style={styles.speedItem}>
              <MaterialIcons name="file-upload" size={24} color={uploadQuality.color} />
              <Text style={styles.speedValue}>{uploadSpeed}</Text>
              <Text style={styles.speedUnit}>Mbps</Text>
              <Text style={styles.speedLabel}>Subida</Text>
              <Text style={[styles.speedQuality, { color: uploadQuality.color }]}>
                {uploadQuality.label}
              </Text>
            </View>

            <View style={styles.speedDivider} />

            <View style={styles.speedItem}>
              <MaterialIcons name="speed" size={24} color={Colors.accent} />
              <Text style={styles.speedValue}>{ping}</Text>
              <Text style={styles.speedUnit}>ms</Text>
              <Text style={styles.speedLabel}>Ping</Text>
              <Text style={[styles.speedQuality, { color: Colors.accent }]}>
                {parseInt(ping) < 50 ? 'Excelente' : 'Bueno'}
              </Text>
            </View>
          </View>

          <GradientButton
            title={isRunning ? 'Ejecutando...' : 'Iniciar Test'}
            onPress={runSpeedTest}
            disabled={isRunning}
            style={styles.startButton}
          />
        </LinearGradient>

        {/* Network Diagnostics */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Diagnóstico de Red</Text>
          {networkDiagnostics.map((item, index) => (
            <View key={index} style={styles.diagnosticItem}>
              <MaterialIcons name={item.icon as any} size={24} color={getStatusColor(item.status)} />
              <View style={styles.diagnosticText}>
                <Text style={styles.diagnosticLabel}>{item.label}</Text>
                <Text style={styles.diagnosticValue}>{item.value}</Text>
              </View>
              <View style={[styles.statusIndicator, { backgroundColor: getStatusColor(item.status) }]} />
            </View>
          ))}
        </View>

        {/* Historical Data */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Historial de Tests</Text>
          <DataCard
            title="Promedio Última Semana"
            value="42.8 Mbps"
            subtitle="↑ 12% vs semana anterior"
            icon="trending-up"
            trend="up"
          />
          
          <DataCard
            title="Mejor Velocidad Registrada"
            value="89.2 Mbps"
            subtitle="Ayer a las 14:30"
            icon="speed"
            trend="up"
          />
          
          <DataCard
            title="Tests Realizados"
            value="247"
            subtitle="En los últimos 30 días"
            icon="assessment"
            trend="neutral"
          />
        </View>

        {/* Network Tips */}
        <LinearGradient
          colors={[Colors.surface, Colors.surfaceLight]}
          style={styles.tipsContainer}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <Text style={styles.tipsTitle}>Consejos para Mejorar la Velocidad</Text>
          
          <View style={styles.tipItem}>
            <MaterialIcons name="location-on" size={20} color={Colors.accent} />
            <Text style={styles.tipText}>Busca áreas con mejor cobertura celular</Text>
          </View>
          
          <View style={styles.tipItem}>
            <MaterialIcons name="devices" size={20} color={Colors.accent} />
            <Text style={styles.tipText}>Limita el número de dispositivos conectados</Text>
          </View>
          
          <View style={styles.tipItem}>
            <MaterialIcons name="update" size={20} color={Colors.accent} />
            <Text style={styles.tipText}>Reinicia tu conexión periódicamente</Text>
          </View>
        </LinearGradient>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 30,
  },
  backButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.text,
    flex: 1,
  },
  speedTestContainer: {
    borderRadius: 20,
    padding: 24,
    marginBottom: 30,
    alignItems: 'center',
    elevation: 6,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
  },
  speedTestTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 20,
  },
  progressContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  progressCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: Colors.accent,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  progressText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
  },
  testPhase: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginBottom: 24,
  },
  speedResults: {
    flexDirection: 'row',
    width: '100%',
    marginBottom: 24,
  },
  speedItem: {
    flex: 1,
    alignItems: 'center',
  },
  speedValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.text,
    marginTop: 8,
  },
  speedUnit: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  speedLabel: {
    fontSize: 14,
    color: Colors.text,
    marginTop: 4,
  },
  speedQuality: {
    fontSize: 10,
    fontWeight: '600',
    marginTop: 2,
  },
  speedDivider: {
    width: 1,
    backgroundColor: Colors.surfaceLight,
    marginHorizontal: 16,
  },
  startButton: {
    width: '100%',
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  diagnosticItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  diagnosticText: {
    flex: 1,
    marginLeft: 12,
  },
  diagnosticLabel: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  diagnosticValue: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginTop: 2,
  },
  statusIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  tipsContainer: {
    borderRadius: 16,
    padding: 20,
    elevation: 4,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  tipsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 16,
  },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  tipText: {
    fontSize: 14,
    color: Colors.text,
    marginLeft: 12,
    flex: 1,
  },
});
