export const Colors = {
  primary: '#2196F3',
  primaryDark: '#1976D2',
  secondary: '#03DAC6',
  background: '#000000',
  surface: '#1a1a2e',
  surfaceLight: '#16213e',
  text: '#ffffff',
  textSecondary: '#b0b0b0',
  accent: '#00E5FF',
  success: '#4CAF50',
  warning: '#FF9800',
  error: '#F44336',
  gradient: {
    primary: ['#2196F3', '#00E5FF'],
    wifi: ['#00E5FF', '#2196F3', '#1976D2']
  }
};