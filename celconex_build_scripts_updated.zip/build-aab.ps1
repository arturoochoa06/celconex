$ZipFile = "2o3aGkTJJHCsocUgngKK8A (1).zip"
$ProjectDir = "CelconexProject"
$OutputDir = "output_aab"

Write-Output "📦 Descomprimiendo proyecto..."
Remove-Item -Recurse -Force $ProjectDir, $OutputDir -ErrorAction SilentlyContinue
Expand-Archive -Path $ZipFile -DestinationPath $ProjectDir

Write-Output "⚙️ Entrando al proyecto..."
Set-Location (Get-ChildItem $ProjectDir | Select-Object -First 1).FullName

Write-Output "🏗️ Construyendo App Bundle..."
./gradlew.bat clean bundleRelease

Write-Output "📂 Copiando resultado..."
Set-Location ..
New-Item -ItemType Directory -Force -Path $OutputDir | Out-Null
Get-ChildItem -Recurse -Filter *.aab | ForEach-Object {
    Copy-Item $_.FullName $OutputDir
}

Write-Output "✅ App Bundle generado en: $OutputDir"
Get-ChildItem $OutputDir
