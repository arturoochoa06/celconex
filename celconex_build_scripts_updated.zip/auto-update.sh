#!/bin/bash
set -e

# Archivo con datos de integridad
JSON_FILE="integrity.json"

# Verifica que exista el JSON
if [ ! -f "$JSON_FILE" ]; then
  echo "❌ No se encontró $JSON_FILE"
  exit 1
fi

# Extraer el código de versión del JSON
VERSION_CODE=$(jq -r '.appIntegrity["código de versión"]' "$JSON_FILE")

# Generar un versionName dinámico (ej: v42-20250910)
VERSION_NAME="v${VERSION_CODE}-$(date +%Y%m%d)"

echo "📦 Actualizando versionCode=$VERSION_CODE y versionName=$VERSION_NAME"

# Ruta del build.gradle (ajústala si está en otra carpeta)
GRADLE_FILE="app/build.gradle"

# Actualizar versionCode
sed -i.bak -E "s/versionCode [0-9]+/versionCode ${VERSION_CODE}/" "$GRADLE_FILE"

# Actualizar versionName
sed -i.bak -E "s/versionName \".*\"/versionName \"${VERSION_NAME}\"/" "$GRADLE_FILE"

echo "✅ build.gradle actualizado"

# Compilar AAB
./gradlew clean bundleRelease

echo "🎉 Nueva versión generada en: app/build/outputs/bundle/release/"
